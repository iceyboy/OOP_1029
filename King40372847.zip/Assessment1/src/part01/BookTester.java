package part01;

public class BookTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Book book1 = new Book("The Hunger Games", "Suzanne Collins", "140713208", BookType.FICTION, 1,
				"First in the ground-breaking HUNGER GAMES trilogy", 8.90);

		Book book2 = new Book("Java, the Complete Reference", "Herbert Schildt", "126046341", BookType.REFERENCE, 12,
				"The definitive guide to Java programming", 32.20);
		
		System.out.println(book1);
		
		System.out.println(book2);

	}

}
